1. Run (setup) winrar-x64-611.exe 
2. Run Unlock_Full.rar
3. Enter password 12345